import { Server, Database, Cloud, Shield, TrendingUp, CheckCircle } from 'lucide-react';

const oracleServices = [
  {
    icon: Cloud,
    title: 'Oracle Cloud Infrastructure (OCI)',
    description: 'Provisionnement, configuration, gestion des ressources cloud, sécurité, haute disponibilité, scalabilité.',
    value: 'Solutions cloud sécurisées et optimisées pour performance et coût',
    stats: { label: 'Disponibilité', value: '99.9%' }
  },
  {
    icon: Database,
    title: 'Bases de données Oracle sur Cloud',
    description: 'Administration Oracle DB sur OCI, optimisation, backup/restauration, réplication, monitoring.',
    value: 'Haute disponibilité, performances maximisées, alerting proactif',
    stats: { label: 'Performance améliorée', value: '+40%' }
  },
  {
    icon: Server,
    title: 'Développement Oracle Apex',
    description: 'Applications métiers sur Oracle Apex : ERP, CRM, reporting, tableaux de bord, automatisation de processus.',
    value: 'Rapidité de développement, interfaces modernes, intégration complète',
    stats: { label: 'Temps dev réduit', value: '-50%' }
  },
  {
    icon: TrendingUp,
    title: 'Migration vers Oracle Cloud',
    description: 'Migration de bases et applications legacy vers Oracle Cloud, optimisation cloud-native, conteneurisation.',
    value: 'Transition sécurisée, réduction coûts IT, performances améliorées',
    stats: { label: 'Réduction coûts', value: '25%' }
  },
  {
    icon: Shield,
    title: 'Support & Infogérance Oracle',
    description: 'Monitoring, maintenance corrective & évolutive, SLA, mise à jour sécurité, audits cloud réguliers.',
    value: 'Support proactif, haute disponibilité, conformité standards sécurité',
    stats: { label: 'Support', value: '24/7' }
  }
];

const caseStudies = [
  {
    title: 'Déploiement Oracle Cloud pour PME',
    mission: 'Migration bases locales → OCI, sécurisation et réplication',
    tech: ['Oracle Cloud Infrastructure', 'Oracle DB', 'Oracle Apex'],
    results: ['Disponibilité 99,9%', 'Sauvegardes automatisées', 'Tableau de bord centralisé'],
    image: 'https://images.pexels.com/photos/1148820/pexels-photo-1148820.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    title: 'Application métier Apex pour microfinance',
    mission: 'ERP interne, reporting, automatisation workflow',
    tech: ['Oracle Apex', 'Oracle DB', 'OCI'],
    results: ['Réduction 30% temps traitement', 'Adoption rapide utilisateurs', 'ROI en 6 mois'],
    image: 'https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    title: 'Optimisation performance Oracle DB',
    mission: 'Audit, tuning, index, partitionnement',
    tech: ['Oracle DB', 'OCI Monitoring', 'Performance Tuning'],
    results: ['Temps requête -40%', 'Monitoring proactif', 'Alertes temps réel'],
    image: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    title: 'Migration legacy → Oracle Cloud',
    mission: 'Applications et bases existantes, conteneurisation, sécurité cloud',
    tech: ['Oracle DB', 'OCI', 'Docker/Kubernetes'],
    results: ['Modernisation sécurisée', 'Réduction coûts 25%', 'SLA respectés'],
    image: 'https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];

export default function OracleSection() {
  return (
    <section id="oracle" className="py-24 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-3 mb-6">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/5/50/Oracle_logo.svg"
              alt="Oracle"
              className="h-12"
            />
            <span className="text-4xl font-bold text-gray-900">+</span>
            <span className="text-4xl font-bold text-blue-600">YNOV-Afrik</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Oracle Cloud, Infrastructure & Apex
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Services avancés autour des technologies Oracle : Cloud, administration, développement Apex,
            solutions intégrées pour PME, fintech et institutions.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-20">
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://images.pexels.com/photos/2881229/pexels-photo-2881229.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Oracle datacenter"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-900 to-transparent"></div>
            <div className="absolute bottom-8 left-8 right-8 text-white">
              <h3 className="text-2xl font-bold mb-2">Infrastructure Oracle de classe mondiale</h3>
              <p className="text-blue-100">Performance, sécurité et disponibilité maximales</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Server className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">50+</p>
              <p className="text-gray-600 text-sm">Bases Oracle gérées</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">99.9%</p>
              <p className="text-gray-600 text-sm">SLA Disponibilité</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Database className="w-6 h-6 text-purple-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">10+</p>
              <p className="text-gray-600 text-sm">Apps Apex déployées</p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <Cloud className="w-6 h-6 text-orange-600" />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">25%</p>
              <p className="text-gray-600 text-sm">Réduction coûts IT</p>
            </div>
          </div>
        </div>

        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Nos Services Oracle</h3>
          <div className="space-y-6">
            {oracleServices.map((service, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                      <service.icon className="w-8 h-8 text-white" />
                    </div>
                  </div>

                  <div className="flex-1">
                    <h4 className="text-2xl font-bold text-gray-900 mb-2">{service.title}</h4>
                    <p className="text-gray-600 mb-3 leading-relaxed">{service.description}</p>
                    <div className="flex items-center space-x-2 text-blue-600 font-medium">
                      <CheckCircle className="w-5 h-5" />
                      <span>{service.value}</span>
                    </div>
                  </div>

                  <div className="flex-shrink-0 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 text-center">
                    <p className="text-sm text-gray-600 mb-1">{service.stats.label}</p>
                    <p className="text-3xl font-bold text-blue-600">{service.stats.value}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Cas Clients Oracle</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {caseStudies.map((study, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="relative h-48">
                  <img
                    src={study.image}
                    alt={study.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                </div>

                <div className="p-6">
                  <h4 className="text-xl font-bold text-gray-900 mb-3">{study.title}</h4>
                  <p className="text-gray-600 mb-4 text-sm italic">{study.mission}</p>

                  <div className="mb-4">
                    <p className="text-sm font-semibold text-gray-700 mb-2">Technologies:</p>
                    <div className="flex flex-wrap gap-2">
                      {study.tech.map((tech, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-semibold text-gray-700 mb-2">Résultats:</p>
                    <ul className="space-y-2">
                      {study.results.map((result, i) => (
                        <li key={i} className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-gray-600">{result}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-red-600 to-orange-500 rounded-2xl p-12 text-center text-white shadow-xl">
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/5/50/Oracle_logo.svg"
            alt="Oracle"
            className="h-16 mx-auto mb-6 brightness-0 invert"
          />
          <h3 className="text-3xl font-bold mb-4">Partenaire Oracle certifié</h3>
          <p className="text-xl mb-8 text-red-50 max-w-2xl mx-auto">
            Expertise Oracle complète : Cloud, DBA, Apex, migration, optimisation, sécurité.
            Accompagnement client et transfert de compétences.
          </p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-red-600 px-8 py-4 rounded-lg font-semibold hover:bg-red-50 transition-colors shadow-lg"
          >
            Parlons de votre projet Oracle
          </button>
        </div>
      </div>
    </section>
  );
}
