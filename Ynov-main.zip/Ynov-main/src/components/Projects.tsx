import { Briefcase, TrendingUp, Users, Award } from 'lucide-react';

const stats = [
  { icon: Briefcase, value: '50+', label: 'Projets livrés', color: 'from-blue-500 to-cyan-500' },
  { icon: Users, value: '30+', label: 'Clients satisfaits', color: 'from-green-500 to-teal-500' },
  { icon: TrendingUp, value: '99.9%', label: 'Taux de disponibilité', color: 'from-purple-500 to-pink-500' },
  { icon: Award, value: '15+', label: 'Ans d\'expérience', color: 'from-orange-500 to-red-500' }
];

const testimonials = [
  {
    name: 'Mohamed Diallo',
    role: 'Directeur IT, Microfinance Solutions',
    company: 'Fintech Corp',
    image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300',
    quote: 'YNOV-Afrik a transformé notre infrastructure IT. La migration vers Oracle Cloud s\'est faite sans interruption et nos performances ont augmenté de 40%. L\'équipe est professionnelle et réactive.',
    rating: 5
  },
  {
    name: 'Fatima Koné',
    role: 'CEO',
    company: 'E-Commerce Plus',
    image: 'https://images.pexels.com/photos/3763188/pexels-photo-3763188.jpeg?auto=compress&cs=tinysrgb&w=300',
    quote: 'Application Oracle Apex développée en temps record. L\'interface est moderne et intuitive. Nos équipes ont adopté la solution immédiatement. Support 24/7 exceptionnel.',
    rating: 5
  },
  {
    name: 'Ibrahim Touré',
    role: 'Responsable Technique',
    company: 'Health Systems',
    image: 'https://images.pexels.com/photos/3760514/pexels-photo-3760514.jpeg?auto=compress&cs=tinysrgb&w=300',
    quote: 'Expertise technique impressionnante. La migration de nos bases legacy vers le cloud a été un succès total. YNOV-Afrik est devenu notre partenaire IT de confiance.',
    rating: 5
  }
];

const technologies = [
  { name: 'React', logo: 'https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg' },
  { name: 'Node.js', logo: 'https://upload.wikimedia.org/wikipedia/commons/d/d9/Node.js_logo.svg' },
  { name: 'Oracle', logo: 'https://upload.wikimedia.org/wikipedia/commons/5/50/Oracle_logo.svg' },
  { name: 'PostgreSQL', logo: 'https://upload.wikimedia.org/wikipedia/commons/2/29/Postgresql_elephant.svg' },
  { name: 'MongoDB', logo: 'https://upload.wikimedia.org/wikipedia/commons/9/93/MongoDB_Logo.svg' },
  { name: 'Docker', logo: 'https://upload.wikimedia.org/wikipedia/commons/4/4e/Docker_%28container_engine%29_logo.svg' },
  { name: 'Kubernetes', logo: 'https://upload.wikimedia.org/wikipedia/commons/3/39/Kubernetes_logo_without_workmark.svg' },
  { name: 'AWS', logo: 'https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg' },
  { name: 'Python', logo: 'https://upload.wikimedia.org/wikipedia/commons/c/c3/Python-logo-notext.svg' },
  { name: 'TypeScript', logo: 'https://upload.wikimedia.org/wikipedia/commons/4/4c/Typescript_logo_2020.svg' }
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-blue-600 font-semibold text-sm uppercase tracking-wide">Nos Réalisations</span>
          <h2 className="mt-4 text-4xl md:text-5xl font-bold text-gray-900">
            Des Résultats Concrets & Mesurables
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            Nous accompagnons nos clients dans leur transformation digitale avec des solutions éprouvées et performantes.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, idx) => (
            <div
              key={idx}
              className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 text-center shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                <stat.icon className="w-8 h-8 text-white" />
              </div>
              <p className="text-4xl font-bold text-gray-900 mb-2">{stat.value}</p>
              <p className="text-gray-600 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Ce que disent nos clients</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-bold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                    <p className="text-sm text-blue-600 font-medium">{testimonial.company}</p>
                  </div>
                </div>

                <div className="flex space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg
                      key={i}
                      className="w-5 h-5 text-yellow-400 fill-current"
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                    </svg>
                  ))}
                </div>

                <p className="text-gray-700 leading-relaxed italic">"{testimonial.quote}"</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">Technologies & Outils</h3>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Nous maîtrisons les technologies les plus avancées pour vous offrir des solutions robustes et évolutives
          </p>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            {technologies.map((tech, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl p-6 flex flex-col items-center justify-center space-y-3 shadow-md hover:shadow-lg transition-shadow"
              >
                <img
                  src={tech.logo}
                  alt={tech.name}
                  className="h-12 w-auto object-contain"
                />
                <p className="text-sm font-medium text-gray-700">{tech.name}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl overflow-hidden shadow-xl">
          <div className="grid md:grid-cols-2">
            <div className="p-12">
              <h3 className="text-3xl font-bold text-white mb-4">
                Prêt à transformer votre entreprise ?
              </h3>
              <p className="text-xl text-blue-50 mb-8">
                Discutons de vos besoins et construisons ensemble la solution idéale pour votre business.
              </p>
              <button
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors shadow-lg"
              >
                Contactez-nous maintenant
              </button>
            </div>

            <div className="relative hidden md:block">
              <img
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Team collaboration"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
