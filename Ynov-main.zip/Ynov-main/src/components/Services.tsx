import { Code, Database, Cloud, Wrench, Shield, TrendingUp, Users, Briefcase } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Développement Logiciel',
    description: 'Applications web, mobile, APIs microservices. Solutions sur mesure avec React, Flutter, Node.js.',
    technologies: ['React', 'Node.js', 'Flutter', 'TypeScript', 'Python'],
    image: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Database,
    title: 'Data Engineering & BI',
    description: 'Administration bases de données, ETL, Data Warehouse, Business Intelligence, reporting & analytics.',
    technologies: ['Oracle DB', 'PostgreSQL', 'MongoDB', 'Tableau', 'Power BI'],
    image: 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: Cloud,
    title: 'Cloud & Infrastructure',
    description: 'Oracle Cloud Infrastructure, hébergement, conteneurisation Docker/Kubernetes, CI/CD, DevOps.',
    technologies: ['Oracle Cloud', 'AWS', 'Docker', 'Kubernetes', 'Terraform'],
    image: 'https://images.pexels.com/photos/1181216/pexels-photo-1181216.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-green-500 to-teal-500'
  },
  {
    icon: Wrench,
    title: 'Migration & Modernisation',
    description: 'Migration legacy vers cloud, refonte UX/UI, optimisation performance, architecture moderne.',
    technologies: ['Migration Tools', 'Microservices', 'Cloud Native', 'API Gateway'],
    image: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Shield,
    title: 'Support & Infogérance',
    description: 'Monitoring 24/7, maintenance corrective/évolutive, backup, SLA garantis, helpdesk.',
    technologies: ['Monitoring', 'Backup', 'SLA', 'Incident Mgmt', 'OTRS'],
    image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-red-500 to-pink-500'
  },
  {
    icon: TrendingUp,
    title: 'Audit & Conseil IT',
    description: 'Audit sécurité, performance, architecture SI, conformité, gouvernance, transformation digitale.',
    technologies: ['Security Audit', 'Performance', 'Compliance', 'Architecture'],
    image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-indigo-500 to-purple-500'
  },
  {
    icon: Briefcase,
    title: 'Solutions Métiers Verticales',
    description: 'ERP, CRM, microfinance, e-commerce, gestion RH, santé, éducation. Solutions packagées.',
    technologies: ['ERP', 'CRM', 'Fintech', 'E-commerce', 'Custom Solutions'],
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-yellow-500 to-orange-500'
  },
  {
    icon: Users,
    title: 'Formation & Accompagnement',
    description: 'Transfert de compétences, documentation, bonnes pratiques, support utilisateurs.',
    technologies: ['Training', 'Documentation', 'Support', 'Best Practices'],
    image: 'https://images.pexels.com/photos/1181622/pexels-photo-1181622.jpeg?auto=compress&cs=tinysrgb&w=800',
    color: 'from-cyan-500 to-blue-500'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-blue-600 font-semibold text-sm uppercase tracking-wide">Nos Services</span>
          <h2 className="mt-4 text-4xl md:text-5xl font-bold text-gray-900">
            Un Catalogue Complet de Services IT
          </h2>
          <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
            De l'architecture à la maintenance, nous couvrons tous vos besoins technologiques avec expertise et qualité.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="group bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border border-gray-100 hover:border-blue-200"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${service.color} opacity-60`}></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <service.icon className="w-16 h-16 text-white" />
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{service.description}</p>

                <div className="flex flex-wrap gap-2">
                  {service.technologies.slice(0, 3).map((tech, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-gray-100 text-gray-700 text-xs rounded-full font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                  {service.technologies.length > 3 && (
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-medium">
                      +{service.technologies.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-2xl p-12 text-center text-white shadow-xl">
          <h3 className="text-3xl font-bold mb-4">Besoin d'une solution personnalisée ?</h3>
          <p className="text-xl mb-8 text-blue-50">
            Nous créons des solutions sur mesure adaptées à vos besoins spécifiques
          </p>
          <button
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-blue-50 transition-colors shadow-lg"
          >
            Discutons de votre projet
          </button>
        </div>
      </div>
    </section>
  );
}
